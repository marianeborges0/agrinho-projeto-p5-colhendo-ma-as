// Variáveis globais
let colherX, colherY;
const colherWidth = 120;
const colherHeight = 20;
let macas = [];
const numMacas = 20; // mais maçãs
let pontos = 0;
const maxPontos = 50;
let faseCompleta = false;
let jogoFinalizado = false;
let faseFimTimer = 0;
const faseFimDelay = 180; // maior pausa para efeito

// Elementos decorativos
let estrelas = [];
const numEstrelas = 50;

// Carregamento de sons e imagens (opcional)
let somPonto, somFim, imagemCesta;

function preload() {
  // Som: você pode colocar seus arquivos aqui
  // somPonto = loadSound('ponto.mp3');
  // somFim = loadSound('fim.mp3');
  // imagemCesta = loadImage('cesta.png');
}

function setup() {
  createCanvas(700, 500);
  iniciarJogo();
  textSize(24);
  textAlign(LEFT, TOP);
  // Criar estrelas decorativas
  for (let i = 0; i < numEstrelas; i++) {
    estrelas.push({
      x: random(width),
      y: random(height),
      size: random(1, 3),
      speed: random(0.2, 0.5)
    });
  }
}

function draw() {
  background(20, 20, 40); // fundo escuro
  desenharEstrelas();

  atualizarCesta();

  if (!jogoFinalizado) {
    atualizarMacas();
    verificarFimDeFase();
    exibirPontuacao();
  } else {
    exibirFimDeJogo();
  }
}

// Funções principais
function iniciarJogo() {
  pontos = 0;
  faseCompleta = false;
  jogoFinalizado = false;
  criarMacas();
  colocarCestaNoCentro();
}

function criarMacas() {
  macas = [];
  for (let i = 0; i < numMacas; i++) {
    macas.push(new Maca());
  }
}

function atualizarCesta() {
  if (!faseCompleta && pontos < maxPontos) {
    colherX = constrain(mouseX, colherWidth / 2, width - colherWidth / 2);
  } else {
    colherX = width / 2;
  }
  desenharCesta();
}

function desenharCesta() {
  fill(139, 69, 19);
  rectMode(CENTER);
  rect(colherX, colherY, colherWidth, colherHeight, 10);
  // Você pode desenhar uma imagem de cesta aqui se preferir
  // image(imagemCesta, colherX - 30, colherY - 15, 60, 30);
}

function atualizarMacas() {
  for (let i = macas.length - 1; i >= 0; i--) {
    let maca = macas[i];
    maca.update();
    maca.display();

    if (maca.checkCaught(colherX, colherY, colherWidth, colherHeight)) {
      macas.splice(i, 1);
      pontos++;
      // if (somPonto) somPonto.play();
      criarEfeitoColeta(maca.x, maca.y);
    } else if (maca.y > height + 20) {
      macas.splice(i, 1);
      macas.push(new Maca());
    }
  }
}

function verificarFimDeFase() {
  if (pontos >= maxPontos && !faseCompleta) {
    faseCompleta = true;
    faseFimTimer = frameCount;
    // if (somFim) somFim.play();
  }

  if (faseCompleta) {
    exibirMensagem("Fase Completa!\nPreparando próxima...");
    if (frameCount - faseFimTimer > faseFimDelay) {
      iniciarNovaFase();
    }
  }
}

function exibirPontuacao() {
  fill(255);
  textSize(24);
  text('Pontuação: ' + pontos, 10, 10);
}

function exibirFimDeJogo() {
  exibirMensagem("Fim de Jogo!\nParabéns!");
  if (frameCount - faseFimTimer > faseFimDelay) {
    // Espera clique ou tecla para reiniciar
    noLoop();
  }
}

function exibirMensagem(msg) {
  fill(255, 255, 0);
  textSize(36);
  textAlign(CENTER, CENTER);
  text(msg, width / 2, height / 2);
}

// Funções de fase
function iniciarNovaFase() {
  pontos = 0;
  faseCompleta = false;
  criarMacas();
  colocarCestaNoCentro();
  loop();
}

function colocarCestaNoCentro() {
  colherY = height - 30;
  colherX = width / 2;
}

// Classe maçã com detalhes e animações
class Maca {
  constructor() {
    this.x = random(20, width - 20);
    this.y = random(-100, -20);
    this.size = 20;
    this.speed = random(2, 5);
    this.bright = random([true, false]);
  }

  update() {
    this.y += this.speed;
  }

  display() {
    // Cor das maçãs com variações
    fill(this.bright ? color(255, 0, 0) : color(200, 50, 50));
    ellipse(this.x, this.y, this.size);
    // Detalhes na maçã
    fill(34, 139, 34);
    triangle(this.x + 5, this.y - 5, this.x + 10, this.y - 15, this.x, this.y - 10);
    stroke(139, 69, 19);
    strokeWeight(2);
    line(this.x, this.y - this.size / 2, this.x, this.y - this.size / 4);
    noStroke();
  }

  checkCaught(colX, colY, colW, colH) {
    let d = dist(this.x, this.y, colX, colY);
    return d < this.size / 2 + colH / 2;
  }
}

// efeitos visuais ao coletar maçãs
function criarEfeitoColeta(x, y) {
  // Pode criar partículas ou brilho
  // Aqui vamos fazer uma pequena explosão de estrelas
  for (let i = 0; i < 8; i++) {
    estrelas.push({
      x: x,
      y: y,
      size: random(1, 2),
      speedX: random(-2, 2),
      speedY: random(-2, 2),
      life: 30
    });
  }
}

function desenharEstrelas() {
  for (let i = estrelas.length - 1; i >= 0; i--) {
    let e = estrelas[i];
    fill(255, 255, 0, e.life * 8);
    noStroke();
    ellipse(e.x, e.y, e.size);
    e.x += e.speedX;
    e.y += e.speedY;
    e.life--;
    if (e.life <= 0) {
      estrelas.splice(i, 1);
    }
  }
}

// Fundo com estrelas móveis
function desenharEstrelasFundo() {
  for (let star of estrelas) {
    fill(255, 255, 0, star.life * 8);
    noStroke();
    ellipse(star.x, star.y, star.size);
    star.x += star.speedX;
    star.y += star.speedY;
    star.life--;
    if (star.life <= 0) {
      star.x = random(width);
      star.y = 0;
      star.life = 30;
    }
  }
}

// Evento para reiniciar jogo
function mousePressed() {
  if (pontos >= maxPontos || faseCompleta) {
    iniciarJogo();
    loop();
  }
}

function keyPressed() {
  if (pontos >= maxPontos || faseCompleta) {
    iniciarJogo();
    loop();
  }
}